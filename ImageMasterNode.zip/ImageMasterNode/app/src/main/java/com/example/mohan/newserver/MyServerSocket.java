package com.example.mohan.newserver;

/**
 * Created by Mohan on 3/18/2018.
 */

import android.os.Environment;
import android.util.Log;
import android.webkit.MimeTypeMap;

import org.apache.http.conn.util.InetAddressUtils;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MyServerSocket {
    OkHttpClient m_client;
    Socket socket = null;
    File imgFile;
    String serverIP;
    String clientRes="";

    long sTRecv,etRecv,stT, recVT, upT, toT = 0;
    long tot=0;
    // private ServerSocket server;
    ServerSocket serverSocket = null;

    public MyServerSocket(String sIP, File imgF) throws Exception {
        this.imgFile=imgF;
        this.serverIP=sIP;
       /* try {
            serverSocket = new ServerSocket(8080, 1, InetAddress.getByName(getIpAddress()));

        } catch (IOException e) {
            System.out.println("Problems serversocket 1 " + e);
        }*/
    }


    public void listen() {
    //  getImages();
       postVideo();
      getTim();
       // System.out.println("Message time1 " + getTim());
       // sndMsg();

    }
    public String getMsg(){
        return clientRes;
    }

















    public void postVideo() {

//Getting connected devices
        //////////////////////////

        String server = "http://192.168.43.1:8080/upload";//http://172.19.17.185:4567";//172.17.125.201;172.19.17.185
        String name = "Mohan";
        String buffer = "";

        try {

            stT = System.currentTimeMillis();
           // System.out.println("server is   " + serverIP);
         //   System.out.println("File  is   " + imgFile.getAbsolutePath());
           String ServerUrl = "http://" + serverIP + ":8080/upload";

            // Use the imgur image upload API as documented at https://api.imgur.com/endpoints/image
            OkHttpClient client = new OkHttpClient.Builder()
                    .connectTimeout(50, TimeUnit.SECONDS)
                    .writeTimeout(50, TimeUnit.SECONDS)
                    .readTimeout(50, TimeUnit.SECONDS)
                    .build();



            String mime = getMimeType(imgFile.getAbsolutePath());
         //   System.out.println("mime  " + mime);

            MediaType mType = MediaType.parse(mime);


            RequestBody requestBody1 = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    //sourceFile is a File as you know
                    .addFormDataPart("image_file_1", "logo-square1.png", RequestBody.create(MediaType.parse(mime), imgFile))
                    .build();

            Request request1 = new Request.Builder()
                    .header("File", imgFile.getName())
                    .url(ServerUrl)
                    .post(requestBody1)
                    .build();


            Response response = client.newCall(request1).execute();
          // clientRes=response.body().string();
            String recvMsg=response.body().string();
            clientRes=recvMsg;
          //  System.out.println("Response is " + recvMsg);

            upT = System.currentTimeMillis();
            tot = upT - stT;
          //  System.out.println("Upload time is  " + (tot));
            toT = tot;


        } catch (Exception ioe) {
            System.out.println("Errors  " + ioe);
        }

    }
public long getTim(){
        return toT;
}

    public static String getMimeType(String url) {
        String type = null;
        String extension = MimeTypeMap.getFileExtensionFromUrl(url);
        if (extension != null) {
            type = MimeTypeMap.getSingleton().getMimeTypeFromExtension(extension);
        }
        return type;
    }
}
