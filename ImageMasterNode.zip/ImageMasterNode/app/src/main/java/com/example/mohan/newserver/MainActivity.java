package com.example.mohan.newserver;

import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import static com.example.mohan.newserver.MyServerSocket.getMimeType;


public class MainActivity extends AppCompatActivity {
    static TextView tv1,tv2,tv3;
    static double TotalTime,ttim=0.0;
    long sTRecv,etRecv,stT, recVT, upT, toT = 0;
    ArrayList<String> fileList = new ArrayList<>();
    ArrayList<String> ipList = new ArrayList<>();
    static int stp=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv1=(TextView)findViewById(R.id.tv1);
        tv2=(TextView)findViewById(R.id.tv2);
        tv3=(TextView)findViewById(R.id.tv3);
    }
    public void start(View v){

        System.out.println("Push the Timer");
       new CountDownTimer(30000,1000 ) {


            public void onFinish() {
                System.out.println("Inside the Timer");

                    controller();
                                 }


            public void onTick(long millisUntilFinished) {
                // millisUntilFinished    The amount of time until finished.
            }
        }.start();
        }

     // controller();




   public void controller(){
      // System.out.println("Inside the controller  ");
       stT = System.currentTimeMillis();
       ArrayList<String> ipList=getClientList();
        int ipSize=ipList.size();
    //   System.out.println("IP size "+ipSize);
       List<File> fileList=getImages();
       int fileSize=fileList.size();
       System.out.println("F size is "+fileSize+ " ipSize is "+ipSize);
        int c=0;
        int f=0;
        for(int t=0; t<fileSize; t++){

            c=0;
            // System.out.println("File is "+fn);
            for(int p=0;p<ipSize;p++){
                File fn=fileList.get(f);
                String ipa=ipList.get(p);
                 System.out.println("F is "+f+ "P is "+p+ "IPA is"+ipa);
                passData(fn,ipa);
                try {
                    Thread.sleep(700);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                f++;
                if (f>(fileSize-1))return;
            }

        }


    }

    public void passData(final File fileN, final String ipAdd) {
        Thread thread = new Thread() {

            long tot;
            String clRes;


            public void run() {
                File fname=fileN;
                String ip=ipAdd;
                Message msg = Message.obtain();

                MyServerSocket app = null;
                try {
                    app=new MyServerSocket(ip,fname);
                    app.listen();
                    tot =app.getTim();
                    clRes=app.clientRes;
                    String msgn=Long.toString(tot);
                    msg.what=Integer.parseInt(msgn);
                    msg.obj=clRes;

                    MainActivity._handler.sendMessage(msg);


                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        };



            thread.start();


    }


    public static Handler _handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {

        double tt=msg.what;
        String ms=(String) msg.obj;

            TotalTime=TotalTime+tt;


          //  tv3.setText("Total Time   "+TotalTime+"");
          tv1.append(ms+" T="+tt+"  \n");
          //  System.out.println("write Results "+tt);
            writeResult(ms+"\t"+tt);
         //  Log.d("system", String.format("Handler.handleMessage(): msg=%s", msg.what));
            // This is where main activity thread receives messages
            // Put here your handling of incoming messages posted by other threads
            super.handleMessage(msg);
            //TotalTime=ttim;
        }

    };

    public ArrayList<String> getClientList() {
        ArrayList<String> clientList = new ArrayList<>();
        BufferedReader br = null;
        try {
            br = new BufferedReader(new FileReader("/proc/net/arp"));
            String line;
            while ((line = br.readLine()) != null) {
                String[] clientInfo = line.split(" +");
                String mac = clientInfo[3];
                if (mac.matches("..:..:..:..:..:..")) { // To make sure its not the title
                    clientList.add(clientInfo[0]);
                }
            }
        } catch (java.io.IOException aE) {
            aE.printStackTrace();
            return null;
        }
        return clientList;
    }


    public static void writeResult(String data){

        File sdcard = Environment.getExternalStorageDirectory();

        File dir = new File(sdcard.getAbsolutePath() + "/Rest/");
        dir.mkdir();
        Date dNow = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("mm");
        String date = dt.format(dNow);
        String fname = dir + "/" +"0"+ date + ".txt";
       // System.out.println("File created  "+fname);
            File file = new File(fname);
        //    System.out.println("File inside write  " + fname);
            stp++;
            try {
                FileWriter fr = new FileWriter(file, true);
                fr.write(data + "\n");
                fr.close();

            } catch (IOException e) {
                e.printStackTrace();
            }


    }


    public List<File> getImages(){
        File sdcard = Environment.getExternalStorageDirectory();

        File dir = new File(sdcard.getAbsolutePath() + "/TestImages/");

        dir.mkdir();
        File folder=dir;
       System.out.println("Folder is   " + folder);

        List<File> fList = new ArrayList<>();

        for (final File f : folder.listFiles()) {
            fList.add(f.getAbsoluteFile());

        }

        for(File name : fList){
           System.out.println("Files are "+name.getName());
        }
        return fList;
    }

   /* public void startX(View v){

        ArrayList<String> ipList=getClientList();
        for (String temp : ipList) {
            System.out.println("IP is "+temp);
        }

        final List<File> flist=getImages();

        for(File files : flist) {
            System.out.println("Files are " + files);

        }
        int filLst=flist.size();

final String sip=ipList.get(0);

        for (int s=0; s<filLst; s++) {

            // MultithreadingDemo obj = new MultithreadingDemo();
            //obj.start();


            final int finalS = s;
            Thread thread = new Thread() {
                int x= finalS;
                File fl=flist.get(x);
                String ip=sip;
                long tot;
                String clRes;
                public void run() {

                    Message msg = Message.obtain();

                    MyServerSocket app = null;
                    try {
                        app = new MyServerSocket(ip,fl);
                        app.listen();
                        tot =app.getTim();
                        clRes=app.clientRes;

                        String msgn=Long.toString(tot);
                       msg.what=Integer.parseInt(msgn);
                        msg.obj=clRes;

                        MainActivity._handler.sendMessage(msg);

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    System.out.println("Thread  Running time "+tot);
                    System.out.println("Thread  cl res "+clRes);
                }
            };

            thread.start();
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }


   }*/




    public void stop(View v){
     System.exit(0);
    }


    public void GetClients(View view) {
        ArrayList<String> ipList=getClientList();
        tv2.setText("");
        tv1.setText("");
        tv3.setText("");
        for (String temp : ipList) {

            tv2.append(temp+"\n");
        }

    }

    public String getFilename() {
        Date dNow = new Date();
        SimpleDateFormat dt = new SimpleDateFormat("mm_ss");
        String date = dt.format(dNow);
        System.out.println("Current Date: " + date);

        //long millis = System.currentTimeMillis();
        // String time=millis+"";

        return date;
    }

}


